﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using StaticVoid.Repository.Demo.Data.Entities;

namespace StaticVoid.Repository.Demo.Data
{
	public class GeekContext : DbContext
	{
		public DbSet<Geek> Geeks { get; set; }
	}
}
