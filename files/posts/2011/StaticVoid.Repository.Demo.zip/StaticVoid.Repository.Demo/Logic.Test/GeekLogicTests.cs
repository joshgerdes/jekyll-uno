﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StaticVoid.Repository.Demo.Data.Entities;
using StaticVoid.Core.Repository;

namespace StaticVoid.Repository.Demo.Logic.Test
{
	[TestClass]
	public class GeekLogicTests
	{
		[TestMethod]
		public void OldGeeksTest()
		{
			List<Geek> geeks = new List<Geek>
			{
				new Geek{
					Id = 1,
					Name = "Bill Gates",
					DateOfBirth = new DateTime(1955,10,24)
				},
				new Geek{
					Id = 2,
					Name = "Steve Jobs",
					DateOfBirth = new DateTime(1955,2,28)
				},
				new Geek{
					Id = 3,
					Name = "Albert Einstein",
					DateOfBirth = new DateTime(1879,3,14)
				}
			};

			IRepositoryDataSource<Geek> geekDataSource = new InMemoryRepositoryDataSource<Geek>(geeks);
			IRepository<Geek> geekRepository = new SimpleRepository<Geek>(geekDataSource);

			GeekLogic sut = new GeekLogic(geekRepository);

			var oldGeeks = sut.OldGeeks(new DateTime(1955, 3, 1)).ToList();

			Assert.AreEqual(2,oldGeeks.Count());
			Assert.AreEqual(2, oldGeeks[0].Id);
			Assert.AreEqual(3, oldGeeks[1].Id);
		}
	}
}
