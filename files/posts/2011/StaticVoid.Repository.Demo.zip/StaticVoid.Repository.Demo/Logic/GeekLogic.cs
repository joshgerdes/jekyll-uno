﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StaticVoid.Repository.Demo.Data.Entities;
using StaticVoid.Core.Repository;

namespace StaticVoid.Repository.Demo.Logic
{
	public class GeekLogic:IGeekLogic
	{
		private IRepository<Geek> m_GeekRepository;

		public GeekLogic(IRepository<Geek> geekRepository) 
		{
			m_GeekRepository = geekRepository;
		}

		#region IGeekLogic Members

		public IEnumerable<Data.Entities.Geek> OldGeeks(DateTime olderThan)
		{
			return m_GeekRepository.GetAll().Where(g => g.DateOfBirth < olderThan).ToList().AsEnumerable();
		}

		#endregion
	}
}
