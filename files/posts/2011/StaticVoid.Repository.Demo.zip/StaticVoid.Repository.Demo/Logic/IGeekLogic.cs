﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StaticVoid.Repository.Demo.Data.Entities;

namespace StaticVoid.Repository.Demo.Logic
{
	public interface IGeekLogic
	{
		IEnumerable<Geek> OldGeeks(DateTime olderThan);
	}
}
