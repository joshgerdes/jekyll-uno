[assembly: WebActivator.PreApplicationStartMethod(typeof(StaticVoid.Repository.Demo.Site.App_Start.NinjectMVC3), "Start")]
[assembly: WebActivator.ApplicationShutdownMethodAttribute(typeof(StaticVoid.Repository.Demo.Site.App_Start.NinjectMVC3), "Stop")]

namespace StaticVoid.Repository.Demo.Site.App_Start
{
    using System.Reflection;
    using Microsoft.Web.Infrastructure.DynamicModuleHelper;
    using Ninject;
    using Ninject.Web.Mvc;
	using StaticVoid.Repository.Demo.Logic;
	using StaticVoid.Core.Repository;
	using System.Data.Entity;
	using StaticVoid.Repository.Demo.Data;

    public static class NinjectMVC3 
    {
        private static readonly Bootstrapper bootstrapper = new Bootstrapper();

        /// <summary>
        /// Starts the application
        /// </summary>
        public static void Start() 
        {
            DynamicModuleUtility.RegisterModule(typeof(OnePerRequestModule));
            DynamicModuleUtility.RegisterModule(typeof(HttpApplicationInitializationModule));
            bootstrapper.Initialize(CreateKernel);
        }
        
        /// <summary>
        /// Stops the application.
        /// </summary>
        public static void Stop()
        {
            bootstrapper.ShutDown();
        }
        
        /// <summary>
        /// Creates the kernel that will manage your application.
        /// </summary>
        /// <returns>The created kernel.</returns>
        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            RegisterServices(kernel);
            return kernel;
        }

        /// <summary>
        /// Load your modules or register your services here!
        /// </summary>
        /// <param name="kernel">The kernel.</param>
        private static void RegisterServices(IKernel kernel)
        {
			//Key components for StaticVoid Repository configuration, this allows injection of IRepository<T> (see GeekLogic)
			//The assumption is that T exists within your EF4.1 entities.

			kernel.Bind<DbContext>().To<GeekContext>().InRequestScope();
			kernel.Bind(typeof(IRepositoryDataSource<>)).To(typeof(DbContextRepositoryDataSource<>)); 
			kernel.Bind(typeof(IRepository<>)).To(typeof(SimpleRepository<>));
			kernel.Bind<IGeekLogic>().To<GeekLogic>();
        }        
    }
}
