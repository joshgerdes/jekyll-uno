﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StaticVoid.Repository.Demo.Logic;
using StaticVoid.Repository.Demo.Site.Models;

namespace StaticVoid.Repository.Demo.Site.Controllers
{
    public class HomeController : Controller
    {
		private IGeekLogic m_GeekLogic;

		public HomeController(IGeekLogic geekLogic)
		{
			m_GeekLogic = geekLogic;
		}

        public ActionResult Index()
        {
			var oldGeeks = m_GeekLogic.OldGeeks(new DateTime(1970, 1, 1));

			return View(new GeekListModel
			{
				Geeks = oldGeeks.Select(g=>new GeekListItemModel{
					Id=g.Id,
					Name = g.Name,
					Age = (int)((new TimeSpan(DateTime.Now.Ticks - g.DateOfBirth.Ticks).Days) / 365.25) // quick and dirty age
				})
			});
        }

    }
}
