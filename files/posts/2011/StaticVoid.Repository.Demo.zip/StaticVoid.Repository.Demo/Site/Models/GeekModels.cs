﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StaticVoid.Repository.Demo.Site.Models
{
	public class GeekListModel
	{
		public IEnumerable<GeekListItemModel> Geeks { get; set; }
	}

	public class GeekListItemModel
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public int Age { get; set; }
	}
}